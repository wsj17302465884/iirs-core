﻿using IIRS.Utilities.Common;
using SqlSugar;
using System.Collections.Generic;

namespace IIRS.Models.EntityModel.BANK
{
    ///<summary>
    ///不动产信息
    ///</summary>
    [SugarTable("REALEST_INF", SysConst.DB_CON_BANK)]
    public partial class REALEST_INF
    {
        /// <summary>
        /// 不动产信息
        /// </summary>
        public REALEST_INF()
        {


        }
        /// <summary>
        /// Desc:
        /// Default:
        /// Nullable:False
        /// </summary>           
        [SugarColumn(IsPrimaryKey = true)]
        public string BID { get; set; }

        /// <summary>
        /// Desc:不动产信息ID
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string BDCXX_ID { get; set; }

        /// <summary>
        /// Desc:不动产权证号汇总
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string REALEST_WRNT_NO_SUM { get; set; }

        /// <summary>
        /// Desc:权利人名称汇总
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string RGHT_PSN_NM_SUM { get; set; }

        /// <summary>
        /// Desc:房屋编码
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string HS_ECD { get; set; }

        /// <summary>
        /// Desc:是否可办理
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string IF_CNHDL { get; set; }

        /// <summary>
        /// Desc:不可办理说明
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string NOT_CNHDL_CMNT { get; set; }

        /// <summary>
        /// Desc:在办情况
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string EXST_STTN { get; set; }

        /// <summary>
        /// Desc:原登记业务号
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string ORI_RGS_BSN_NO { get; set; }

        /// <summary>
        /// Desc:不动产单元号
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string REALEST_UNIT_NO { get; set; }

        /// <summary>
        /// Desc:所属区县编码
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string BLNG_CNTYANDDSTC_ECD { get; set; }

        /// <summary>
        /// Desc:所属区县名称
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string BLNG_CNTYANDDSTC_NM { get; set; }

        /// <summary>
        /// Desc:
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string DYRXX_ID { get; set; }

        /// <summary>
        /// Desc:被抵押次数
        /// Default:
        /// Nullable:False
        /// </summary>           
        public decimal HAD_MRTG_CNT { get; set; }

        /// <summary>
        /// Desc:被查封次数
        /// Default:
        /// Nullable:False
        /// </summary>           
        public decimal HAD_SEALUP_CNT { get; set; }

        /// <summary>
        /// Desc:抵押顺位位次
        /// Default:
        /// Nullable:False
        /// </summary>           
        public decimal MRTG_ORDER_PRCD { get; set; }

        /// <summary>
        /// Desc:是否存在其他抵押情况
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IF_EXST_OTHR_MRTG_STTN { get; set; }

        /// <summary>
        /// Desc:是否存在抵押权预告登记
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IF_EXST_MRTG_WGHT_FRCST_RGS { get; set; }

        /// <summary>
        /// Desc:是否存在预告登记
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IF_EXST_FRCST_RGS { get; set; }

        /// <summary>
        /// Desc:是否存在异议登记
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IF_EXST_OBJTN_RGS { get; set; }

        /// <summary>
        /// Desc:
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string YYDJMX_ID { get; set; }

        /// <summary>
        /// Desc:抵押权预告登记次数
        /// Default:
        /// Nullable:False
        /// </summary>           
        public decimal MRTG_WGHT_FRCST_RGS_CNT { get; set; }

        /// <summary>
        /// Desc:预告登记次数
        /// Default:
        /// Nullable:False
        /// </summary>           
        public decimal FRCST_RGS_CNT { get; set; }

        /// <summary>
        /// Desc:异议登记次数
        /// Default:
        /// Nullable:False
        /// </summary>           
        public decimal OBJTN_RGS_CNT { get; set; }

        /// <summary>
        /// Desc:房屋坐落
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string HS_LO { get; set; }

        /// <summary>
        /// Desc:总层数
        /// Default:
        /// Nullable:True
        /// </summary>           
        public decimal? TOT_LYR_NUM { get; set; }

        /// <summary>
        /// Desc:房屋所在层数
        /// Default:
        /// Nullable:True
        /// </summary>           
        public decimal? HS_WBT_LYR_NUM { get; set; }

        /// <summary>
        /// Desc:房屋结构
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string HS_STC { get; set; }

        /// <summary>
        /// Desc:土地使用权人名称
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string LAND_US_WGHT_PSN_NM { get; set; }

        /// <summary>
        /// Desc:土地性质
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string LAND_CHAR { get; set; }

        /// <summary>
        /// Desc:土地使用期限（结束日期）
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string LAND_US_DDLN { get; set; }

        /// <summary>
        /// Desc:不动产权人名称
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string REALEST_WGHT_PSN_NM { get; set; }

        /// <summary>
        /// Desc:不动产权人证件号码
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string REALEST_WGHT_PSN_ { get; set; }

        /// <summary>
        /// Desc:房屋建筑面积
        /// Default:
        /// Nullable:True
        /// </summary>           
        public decimal HS_CNSTRCTAREA { get; set; }

        /// <summary>
        /// Desc:房屋建筑面积单位
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string HS_CNSTRCTAREA_UNIT { get; set; }

        /// <summary>
        /// Desc:房屋套内面积
        /// Default:
        /// Nullable:False
        /// </summary>           
        public decimal HS_SET_INNR_AREA { get; set; }

        /// <summary>
        /// Desc:房屋公摊面积
        /// Default:
        /// Nullable:False
        /// </summary>           
        public decimal HS_PUBLIC_AREA { get; set; }

        /// <summary>
        /// Desc:实测建筑面积
        /// Default:
        /// Nullable:True
        /// </summary>           
        public decimal REALI_CNSTRCTAREA { get; set; }

        /// <summary>
        /// Desc:土地分摊面积
        /// Default:
        /// Nullable:False
        /// </summary>           
        public decimal LAND_APOR_AREA { get; set; }

        /// <summary>
        /// Desc:房屋用途
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string HS_USE { get; set; }

        /// <summary>
        /// Desc:土地用途
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string LAND_USE { get; set; }

        /// <summary>
        /// Desc:宗地使用权起始日期
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string LND_US_WGHT_STDT { get; set; }

        /// <summary>
        /// Desc:宗地使用权终止日期
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string LND_US_WGHT_TMDT { get; set; }

        /// <summary>
        /// Desc:宗地权利类型
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string LND_RGHT_TP { get; set; }

        /// <summary>
        /// Desc:宗地权利性质
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string LND_RGHT_CHAR { get; set; }

        /// <summary>
        /// Desc:权证附记
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string WRNT_ATCH { get; set; }

        /// <summary>
        /// Desc:房屋序号
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string HS_SN { get; set; }

        /// <summary>
        /// Desc:权利份额
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string WGHT_LOT { get; set; }

        /// <summary>
        /// Desc:查询时间
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string ENQR_TM { get; set; }

        /// <summary>
        /// Desc:共有情况
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string COM_STTN { get; set; }

        /// <summary>
        /// Desc:房屋性质
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string HS_CHAR_NM { get; set; }

        /// <summary>
        /// Desc:房屋类型
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string HS_TP { get; set; }

        /// <summary>
        /// Desc:房屋初始登记时间
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string HS_INL_RGTM { get; set; }

        /// <summary>
        /// Desc:权利类型
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string RGHT_TP { get; set; }

        /// <summary>
        /// Desc:权利终止日期
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string RGHT_TMDT { get; set; }

        /// <summary>
        /// Desc:登薄日期
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string RG_DT { get; set; }

        /// <summary>
        /// Desc:是否占用
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string IF_OCP { get; set; }

        /// <summary>
        /// Desc:是否抵押
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string REC_MRTG { get; set; }

        /// <summary>
        /// Desc:是否查封
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IF_SEALUP { get; set; }

        /// <summary>
        /// Desc:查封信息ID
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string CFXX_ID { get; set; }

        /// <summary>
        /// Desc:行政限制ID
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string XZXZ_ID { get; set; }

        /// <summary>
        /// Desc:权利登记信息ID
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string QLDJXX_ID { get; set; }
        /// <summary>
        /// 抵押人信息
        /// </summary>
        public List<MRTG_PSN_INF> MRTG_PSN_INF { get; set; } = new List<MRTG_PSN_INF>();
        /// <summary>
        /// 查封信息
        /// </summary>
        public List<SEALUP_INF> SEALUP_INF { get; set; } = new List<SEALUP_INF>();
        /// <summary>
        /// 行政限制
        /// </summary>
        public List<Admn_Rst> Admn_Rst { get; set; } = new List<Admn_Rst>();
        /// <summary>
        /// 权利登记信息
        /// </summary>
        public List<Rght_Rgs_Inf> Rght_Rgs_Inf { get; set; } = new List<Rght_Rgs_Inf>();

    }
}
