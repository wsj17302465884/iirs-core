﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IIRS.Models.EntityModel.BANK
{
    /// <summary>
    /// 权利人信息
    /// </summary>
    public class Rght_Psn_Inf
    {
        public Rght_Psn_Inf()
        {

        }
        /// <summary>
        /// 权利人名称
        /// </summary>
        public string Rght_Psn_Nm { get; set; }
        /// <summary>
        /// 权利人编号
        /// </summary>
        public string Rght_Psn_No { get; set; }
        /// <summary>
        /// 权利人类型
        /// </summary>
        public string Rght_Psn_Tp { get; set; }
        /// <summary>
        /// 权利人证件类型
        /// </summary>
        public string Rght_Psn_Crdt_Tp { get; set; }
        /// <summary>
        /// 权利人证件号码
        /// </summary>
        public string Rght_Psn_Crdt_No { get; set; }
        /// <summary>
        /// 法定代表人名称
        /// </summary>
        public string Lgl_Rprs { get; set; }
    }
}
