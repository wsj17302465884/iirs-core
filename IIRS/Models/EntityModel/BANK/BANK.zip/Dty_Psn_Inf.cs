﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IIRS.Models.EntityModel.BANK
{
    /// <summary>
    /// 义务人信息
    /// </summary>
    public class Dty_Psn_Inf
    {
        public Dty_Psn_Inf()
        {

        }
        /// <summary>
        /// 义务人名称
        /// </summary>
        public string Dty_Psn_Nm { get; set; }
        /// <summary>
        /// 义务人类型
        /// </summary>
        public string Dty_Psn_Tp { get; set; }
        /// <summary>
        /// 义务人证件类型
        /// </summary>
        public string Dty_Psn_Crdt_Tp { get; set; }
        /// <summary>
        /// 义务人证件号码
        /// </summary>
        public string Dty_Psn_Crdt_No { get; set; }
    }
}
