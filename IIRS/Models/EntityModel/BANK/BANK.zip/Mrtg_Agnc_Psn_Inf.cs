﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IIRS.Models.EntityModel.BANK
{
    /// <summary>
    /// 抵押人代理人信息
    /// </summary>
    public class Mrtg_Agnc_Psn_Inf
    {
        public Mrtg_Agnc_Psn_Inf()
        {

        }
        /// <summary>
        /// 抵押人代理人名称
        /// </summary>
        public string Mrtg_Agnc_Psn_Nm { get; set; }
        /// <summary>
        /// 抵押人代理人类型
        /// </summary>
        public string Mrtg_Agnc_Psn_Tp { get; set; }
        /// <summary>
        /// 抵押人代理机构名称
        /// </summary>
        public string Mrtg_Agnc_Inst_Nm { get; set; }
        /// <summary>
        /// 抵押人代理人证件类型
        /// </summary>
        public string Mrtg_Agnc_Psn_Crdt_Tp { get; set; }
        /// <summary>
        /// 抵押人代理人证件号码
        /// </summary>
        public string Mrtg_Agnc_Psn_Crdt_No { get; set; }
        /// <summary>
        /// 抵押人代理人联系电话
        /// </summary>
        public string Mrtg_Agnc_Psn_Ctc_Tel { get; set; }
    }
}
