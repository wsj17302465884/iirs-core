﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IIRS.Models.EntityModel.BANK
{
    /// <summary>
    /// 上传授权委托书
    /// </summary>
    public class ScsqwtsModel
    {
        public ScsqwtsModel()
        {

        }

        /// <summary>
        /// 来源系统
        /// </summary>
        public string SrcSys { get; set; }
        /// <summary>
        /// 多法人标识
        /// </summary>
        public string SvrlLgPsn_Idr { get; set; }
        /// <summary>
        /// 地区码
        /// </summary>
        public string Rgon_CD { get; set; }
        /// <summary>
        /// 不动产所属省份代码
        /// </summary>
        public string Province_Cd { get; set; }
        /// <summary>
        /// 不动产所属城市代码
        /// </summary>
        public string City_Cd { get; set; }
        /// <summary>
        /// 不动产所属区县代码
        /// </summary>
        public string District_Cd { get; set; }
        /// <summary>
        /// 贷款主办机构
        /// </summary>
        public string Ln_Host_Inst { get; set; }

        /// <summary>
        /// 系统参考号
        /// </summary>
        public string Txn_Stm_Ref_No { get; set; }
        /// <summary>
        /// 操作用户编码
        /// </summary>
        public string Mnplt_Usr_ECD { get; set; }
        /// <summary>
        /// 操作用户名称
        /// </summary>
        public string Mnplt_Usr_Nm { get; set; }
        /// <summary>
        /// 不动产登记证明号
        /// </summary>
        public string RealEst_RgsCtf_No { get; set; }
        /// <summary>
        /// 不动产权证号
        /// </summary>
        public string RealEst_Wrnt_No { get; set; }
        /// <summary>
        /// 不动产单元号
        /// </summary>
        public string RealEst_Unit_No { get; set; }
        /// <summary>
        /// 委托人名称
        /// </summary>
        public string Trstr_Nm { get; set; }
        /// <summary>
        /// 委托人类型
        /// </summary>
        public string Trstr_Tp { get; set; }
        /// <summary>
        /// 委托人证件号码
        /// </summary>
        public string Trstr_Crdt_Nm { get; set; }
        /// <summary>
        /// 委托书类型
        /// </summary>
        public string MandDoc_Tp { get; set; }
        /// <summary>
        /// 委托书编号
        /// </summary>
        public string MandDoc_ID { get; set; }
        /// <summary>
        /// 经办人签字日期
        /// </summary>
        public string RspbPsn_Sgn_Dt { get; set; }
        /// <summary>
        /// 代理人名称
        /// </summary>
        public string Agnc_Psn_Nm { get; set; }
        /// <summary>
        /// 代理人联系电话
        /// </summary>
        public string Agnc_Psn_Ctc_Tel { get; set; }
        /// <summary>
        /// 代理人证件号码
        /// </summary>
        public string Agnc_Psn_Crdt_No { get; set; }
        /// <summary>
        /// 代理人签字日期
        /// </summary>
        public string Agnc_Psn_Sgn_Dt { get; set; }
        /// <summary>
        /// 有效期开始时间
        /// </summary>
        public string AvlDt_StTm { get; set; }
        /// <summary>
        /// 有效期结束时间
        /// </summary>
        public string AvlDt_EdTm { get; set; }
        /// <summary>
        /// 附件ID
        /// </summary>
        public string Atch_Id { get; set; }
        /// <summary>
        /// 附件名称
        /// </summary>
        public string Atch_Nm { get; set; }
        /// <summary>
        /// 附件大小
        /// </summary>
        public string Atch_Sz { get; set; }
        /// <summary>
        /// 附件类型
        /// </summary>
        public string Atch_Tp { get; set; }

        public ScsqwtsResultModel scsqwtsResultModel { get; set; }
    }

    public class ScsqwtsResultModel
    {
        public string Ret_Code { get; set; }

        public string Ret_Data { get; set; }
    }
}
