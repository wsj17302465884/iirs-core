﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IIRS.Models.EntityModel.BANK
{
    /// <summary>
    /// 现房抵押登记申请
    /// </summary>
    public class XfdydjsqModel
    {
        public XfdydjsqModel()
        {

        }
        /// <summary>
        /// 来源系统
        /// </summary>
        public string SrcSys { get; set; }
        /// <summary>
        /// 系统参考号
        /// </summary>
        public string Txn_Stm_Ref_No { get; set; }
        /// <summary>
        /// 多法人标识
        /// </summary>
        public string SvrlLgPsn_Idr { get; set; }
        /// <summary>
        /// 地区码
        /// </summary>
        public string Rgon_CD { get; set; }
        /// <summary>
        /// 原交易系统参考号
        /// </summary>
        public string Ori_Txn_Stm_Ref_No { get; set; }
        /// <summary>
        /// 补正标志
        /// </summary>
        public string SplmCrt_Ind { get; set; }
        /// <summary>
        /// 业务申请号
        /// </summary>
        public string Bapl_No { get; set; }
        /// <summary>
        /// 贷款主办机构
        /// </summary>
        public string Ln_Host_Inst { get; set; }
        /// <summary>
        /// 受理人编码
        /// </summary>
        public string Acpt_Psn_ECD { get; set; }
        /// <summary>
        /// 受理人名称
        /// </summary>
        public string Acpt_Psn_Nm { get; set; }
        /// <summary>
        /// 受理时间
        /// </summary>
        public string Acpt_Tm { get; set; }
        /// <summary>
        /// 受理人联系电话
        /// </summary>
        public string Acpt_Psn_Ctc_Tel { get; set; }
        /// <summary>
        /// 受理人证件类型
        /// </summary>
        public string Acpt_Psn_Crdt_Tp { get; set; }
        /// <summary>
        /// 受理人证件号码
        /// </summary>
        public string Acpt_Psn_Crdt_No { get; set; }
        /// <summary>
        /// 短信联系人名称
        /// </summary>
        public string Sms_CtcPsn_Nm { get; set; }
        /// <summary>
        /// 短信联系人联系电话
        /// </summary>
        public string Sms_CtcPsn_Ctc_Tel { get; set; }

        /// <summary>
        /// 操作用户编码
        /// </summary>
        public string Mnplt_Usr_ECD { get; set; }
        /// <summary>
        /// 操作用户名称
        /// </summary>
        public string Mnplt_Usr_Nm { get; set; }
        /// <summary>
        /// 操作员所在机构名称
        /// </summary>
        public string Mnplt_Usr_Wbt_Inst_Nm { get; set; }
        /// <summary>
        /// 操作员所在机构代码
        /// </summary>
        public string Mnplt_Usr_Wbt_Inst_Cd { get; set; }
        /// <summary>
        /// 操作用户意见
        /// </summary>
        public string Mnplt_Usr_Opin { get; set; }
        /// <summary>
        /// 登记类型
        /// </summary>
        public string Rgs_Tp { get; set; }
        /// <summary>
        /// 登记原因
        /// </summary>
        public string Rgs_Rsn { get; set; }
        /// <summary>
        /// 申报状态
        /// </summary>
        public string Dcl_St { get; set; }
        /// <summary>
        /// 申请时间
        /// </summary>
        public string Aply_Tm { get; set; }
        /// <summary>
        /// 申请类型
        /// </summary>
        public string Aply_Tp { get; set; }
        /// <summary>
        /// 上报组织
        /// </summary>
        public string Rpt_Org { get; set; }
        /// <summary>
        /// 产别
        /// </summary>
        public string HsPty_Cgy { get; set; }
        /// <summary>
        /// 预约类型
        /// </summary>
        public string Rsrvtn_Tp { get; set; }
        /// <summary>
        /// 关联类型
        /// </summary>
        public string Rltv_Tp { get; set; }
        /// <summary>
        /// 关联数据
        /// </summary>
        public string Rltv_Data { get; set; }
        /// <summary>
        /// 不动产所属区域
        /// </summary>
        public string RealEst_Blng_Rgon { get; set; }
        /// <summary>
        /// 最高额抵押担保的债权确定情形
        /// </summary>
        public string High_Mrtg_Wrnt_Clm_Detr { get; set; }
        /// <summary>
        /// 银行业务受理号
        /// </summary>
        public string Bnk_Bsn_Acpt_No { get; set; }
        /// <summary>
        /// 合同及债权情况
        /// </summary>
        public List<Ctr_And_Clm_Sttn> Ctr_And_Clm_Sttn { get; set; }
        /// <summary>
        /// 银行经办代理人信息
        /// </summary>
        public List<Bnk_Hdl_Agnc_Psn_Inf> Bnk_Hdl_Agnc_Psn_Inf { get; set; }
        /// <summary>
        /// 出卖人信息
        /// </summary>
        public List<Sell_Psn_Inf> Sell_Psn_Inf { get; set; }
        /// <summary>
        /// 附件
        /// </summary>
        public List<Atch> Atch { get; set; }
    }

    public class XfdydjsqResultModel
    {
        public string Ret_Code { get; set; }
        public string Ret_Data { get; set; }
    }
    

}
