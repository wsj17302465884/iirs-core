﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IIRS.Models.EntityModel.BANK
{
    public class YzhdyCxModel
    {
        public YzhdyCxModel()
        {

        }
        /// <summary>
        /// 来源系统
        /// </summary>
        public string SrcSys { get; set; }
        /// <summary>
        /// 系统参考号
        /// </summary>
        public string Txn_Stm_Ref_No { get; set; }
        /// <summary>
        /// 多法人标识
        /// </summary>
        public string SvrlLgPsn_Idr { get; set; }
        /// <summary>
        /// 地区码
        /// </summary>
        public string Rgon_CD { get; set; }
        /// <summary>
        /// 不动产所属省份代码
        /// </summary>
        public string Province_Cd { get; set; }
        /// <summary>
        /// 不动产所属城市代码
        /// </summary>
        public string City_Cd { get; set; }
        /// <summary>
        /// 不动产所属区县代码
        /// </summary>
        public string District_Cd { get; set; }
        /// <summary>
        /// 贷款主办机构
        /// </summary>
        public string Ln_Host_Inst { get; set; }
        /// <summary>
        /// 操作用户编码
        /// </summary>
        public string Mnplt_Usr_ECD { get; set; }
        /// <summary>
        /// 操作用户名称
        /// </summary>
        public string Mnplt_Usr_Nm { get; set; }
        /// <summary>
        /// 操作用户岗位名称
        /// </summary>
        public string Mnplt_Usr_Pst { get; set; }
        /// <summary>
        /// 操作员所在机构名称
        /// </summary>
        public string Mnplt_Usr_Wbt_Inst_Nm { get; set; }
        /// <summary>
        /// 操作员所在机构代码
        /// </summary>
        public string Mnplt_Usr_Wbt_Inst_Cd { get; set; }
        /// <summary>
        /// 不动产单元号
        /// </summary>
        public string RealEst_Unit_No { get; set; }
        /// <summary>
        /// 不动产权证号
        /// </summary>
        public string RealEst_Wrnt_No { get; set; }
        /// <summary>
        /// 不动产登记证明号
        /// </summary>
        public string RealEst_RgsCtf_No { get; set; }
        /// <summary>
        /// 抵押预告证明号
        /// </summary>
        public string Mrtg_Frcst_RgsCtf_No { get; set; }
        /// <summary>
        /// 抵押权人名称
        /// </summary>
        public string Mrtg_Wght_Psn_Nm { get; set; }
        /// <summary>
        /// 不动产权人姓名
        /// </summary>
        public string RealEst_Wght_Psn_Nm { get; set; }
        /// <summary>
        /// 不动产权人类型
        /// </summary>
        public string RealEst_Wght_Psn_Tp { get; set; }
        /// <summary>
        /// 不动产权人证件类型
        /// </summary>
        public string RealEst_Wght_Psn_Crdt_Tp { get; set; }
        /// <summary>
        /// 不动产权人证件号码
        /// </summary>
        public string RealEst_Wght_Psn_Crdt_No { get; set; }
        /// <summary>
        /// 业务件号
        /// </summary>
        public string Bsn_Pts_No { get; set; }
        /// <summary>
        /// 业务标识
        /// </summary>
        public string Bsn_Idr { get; set; }
        /// <summary>
        /// 商品房买卖合同编号
        /// </summary>
        public string CmrclHs_BuySell_Ctr_ID { get; set; }
        /// <summary>
        /// 买受人名称
        /// </summary>
        public string Buy_Psn_Nm { get; set; }
        /// <summary>
        /// 是否新房
        /// </summary>
        public string If_NewHs { get; set; }
        /// <summary>
        /// 不动产坐落
        /// </summary>
        public string HsLocation { get; set; }
        /// <summary>
        /// 审核人编码
        /// </summary>
        public string Chk_Psn_ECD { get; set; }
        /// <summary>
        /// 查询目的
        /// </summary>
        public string Enqr_Pps { get; set; }
        /// <summary>
        /// 是否产权人授权
        /// </summary>
        public string If_Own_Psn_Ahn { get; set; }

        public List<YzhdyResultModel> YzhdyResultList { get; set; }
    }
    /// <summary>
    /// 响应结果
    /// </summary>
    public class YzhdyResultModel
    {
        /// <summary>
        /// 返回码
        /// </summary>
        public string Ret_Code { get; set; }
        /// <summary>
        /// 返回说明
        /// </summary>
        public string Ret_Data { get; set; }
        /// <summary>
        /// 业务件号
        /// </summary>
        public string Bsn_Pts_No { get; set; }
        /// <summary>
        /// 原抵押业务ID
        /// </summary>
        public string Ori_Mrtg_BsnID { get; set; }
        /// <summary>
        /// 是否可合并办理注销+抵押
        /// </summary>
        public string If_Can_Mrg_Lout_And_Mrtg { get; set; }
        /// <summary>
        /// 不可合并办理的原因
        /// </summary>
        public string Not_Can_Mrtg_Rsn { get; set; }
        /// <summary>
        /// 不动产登记证明号
        /// </summary>
        public string RealEst_RgsCtf_No { get; set; }

        public List<Mrtg_Wght_Psn_Inf> Mrtg_Wght_Psn_InfList { get; set; }
        /// <summary>
        /// 抵押方式
        /// </summary>
        public string Mrtg_Mod { get; set; }
        public List<RealEst_Inf> RealEst_Inf { get; set; }

        public List<Frcst_Rgs_Inf> Frcst_Rgs_Inf { get; set; }

        public List<CmrclHs_Ctr_Flg_Inf> CmrclHs_Ctr_Flg_Inf { get; set; }

        public List<Stk_Ctr_Flg_Inf> Stk_Ctr_Flg_Inf { get; set; }
    }
    
}
