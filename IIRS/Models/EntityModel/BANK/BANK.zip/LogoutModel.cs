﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IIRS.Models.EntityModel.BANK
{
    public class LogoutModel
    {
        public LogoutModel()
        {

        }
        /// <summary>
        /// 来源系统
        /// </summary>
        public string SrcSys { get; set; }
        /// <summary>
        /// 系统参考号
        /// </summary>
        public string Txn_Stm_Ref_No { get; set; }
        /// <summary>
        /// 多法人标识
        /// </summary>
        public string SvrlLgPsn_Idr { get; set; }
        /// <summary>
        /// 地区码
        /// </summary>
        public string Rgon_CD { get; set; }
        /// <summary>
        /// 受理站点
        /// </summary>
        public string Acpt_Area { get; set; }
        /// <summary>
        /// 贷款主办机构
        /// </summary>
        public string Ln_Host_Inst { get; set; }
        /// <summary>
        /// 操作用户编码
        /// </summary>
        public string Mnplt_Usr_ECD { get; set; }
        /// <summary>
        /// 操作用户名称
        /// </summary>
        public string Mnplt_Usr_Nm { get; set; }
        /// <summary>
        /// 操作员所在机构名称
        /// </summary>
        public string Mnplt_Usr_Wbt_Inst_Nm { get; set; }
        /// <summary>
        /// 操作员所在机构代码
        /// </summary>
        public string Mnplt_Usr_Wbt_Inst_Cd { get; set; }
        /// <summary>
        /// 申请时间
        /// </summary>
        public string Aply_Tm { get; set; }
        /// <summary>
        /// 申请类型
        /// </summary>
        public string Aply_Tp { get; set; }
        /// <summary>
        /// 业务件号
        /// </summary>
        public string Bsn_Pts_No { get; set; }
        /// <summary>
        /// 登记类型
        /// </summary>
        public string Rgs_Tp { get; set; }
        /// <summary>
        /// 抵押类型
        /// </summary>
        public string Mrtg_Tp { get; set; }
        /// <summary>
        /// 注销原因
        /// </summary>
        public string LOut_Rsn { get; set; }
        /// <summary>
        /// 结清状态
        /// </summary>
        public string Clsg_St { get; set; }
        /// <summary>
        /// 预告登记证号
        /// </summary>
        public string Frcst_RgsCtf_No { get; set; }
        /// <summary>
        /// 不动产登记证明号
        /// </summary>
        public string RealEst_Ecb_No { get; set; }
        /// <summary>
        /// 抵押合同号
        /// </summary>
        public string Mrtg_Ctr_No { get; set; }
        /// <summary>
        /// 主债权担保金额
        /// </summary>
        public decimal? Prim_Clm_Wrnt_Amt { get; set; }
        /// <summary>
        /// 最高债权数额
        /// </summary>
        public decimal? Hgst_Clm_Num_Amt { get; set; }
        /// <summary>
        /// 商业贷款
        /// </summary>
        public decimal? Cmrc_Ln { get; set; }
        /// <summary>
        /// 公积金贷款
        /// </summary>
        public decimal? PrFdLn { get; set; }
        /// <summary>
        /// 债务履行期限（债权确定期间、抵押期限）开始
        /// </summary>
        public string Ln_StTm { get; set; }
        /// <summary>
        /// 债务履行期限（债权确定期间、抵押期限）截止
        /// </summary>
        public string Ln_EdTm { get; set; }
        /// <summary>
        /// 业务申请号
        /// </summary>
        public string Bapl_No { get; set; }
        /// <summary>
        /// 抵押权人名称
        /// </summary>
        public string Mrtg_Wght_Psn_Nm { get; set; }
        /// <summary>
        /// 抵押权人证件类型
        /// </summary>
        public string Mrtg_Wght_Psn_Crdt_Tp { get; set; }
        /// <summary>
        /// 抵押权人证件号码
        /// </summary>
        public string Mrtg_Wght_Psn_Crdt_No { get; set; }
        /// <summary>
        /// 抵押权人联系电话
        /// </summary>
        public string Mrtg_Wght_Psn_Ctc_Tel { get; set; }
        /// <summary>
        /// 抵押权人类型
        /// </summary>
        public string Mrtg_Wght_Psn_Tp { get; set; }
        /// <summary>
        /// 抵押权人法定代表或负责人
        /// </summary>
        public string Mrtg_Wght_Psn_Lgl_Tbl_Or_Pnp { get; set; }
        /// <summary>
        /// 抵押权人地址
        /// </summary>
        public string Mrtg_Wght_Psn_Adr { get; set; }
        /// <summary>
        /// 抵押代理人名称
        /// </summary>
        public string Mrtg_Agnc_Psn_Nm { get; set; }
        /// <summary>
        /// 抵押代理人证件类型
        /// </summary>
        public string Mrtg_Agnc_Psn_Crdt_Tp { get; set; }
        /// <summary>
        /// 抵押代理人证件号码
        /// </summary>
        public string Mrtg_Agnc_Psn_Crdt_No { get; set; }
        /// <summary>
        /// 抵押代理人联系电话
        /// </summary>
        public string Mrtg_Agnc_Psn_Ctc_Tel { get; set; }
        /// <summary>
        /// 最高额抵押担保的债权确定情形
        /// </summary>
        public string High_Mrtg_Wrnt_Clm_Detr { get; set; }
        /// <summary>
        /// 是否真实表示
        /// </summary>
        public string True_Exps { get; set; }
        /// <summary>
        /// 是否共有房屋
        /// </summary>
        public string Com_Hs { get; set; }

        public List<Mrtg_RealEst_Unit_Inf> Mrtg_RealEst_Unit_InfList { get; set; }

        public List<Brwr_Inf> Brwr_Inf { get; set; }

        public List<Atch> AtchList { get; set; }
    }  
}
