﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IIRS.Models.EntityModel.BANK
{
    /// <summary>
    /// 未在行抵押请求结果
    /// </summary>
    public class WzhdyResult
    {
        /// <summary>
        /// 未在行抵押请求结果
        /// </summary>
        public WzhdyResult()
        {

        }
    }
}
