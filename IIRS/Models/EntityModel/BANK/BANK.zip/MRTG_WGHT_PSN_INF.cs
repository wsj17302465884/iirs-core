﻿using IIRS.Utilities.Common;
using SqlSugar;
using System.Collections.Generic;

namespace IIRS.Models.EntityModel.BANK
{
    ///<summary>
    ///抵押权人信息
    ///</summary>
    [SugarTable("MRTG_WGHT_PSN_INF", SysConst.DB_CON_BANK)]
    public partial class MRTG_WGHT_PSN_INF
    {
        /// <summary>
        /// 抵押权人信息
        /// </summary>
        public MRTG_WGHT_PSN_INF()
        {


        }
        /// <summary>
        /// Desc:
        /// Default:
        /// Nullable:False
        /// </summary>           
        [SugarColumn(IsPrimaryKey = true)]
        public string MID { get; set; }

        /// <summary>
        /// Desc:抵押权人类型
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string MRTG_WGHT_PSN_TP { get; set; }

        /// <summary>
        /// Desc:抵押权人类别
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string MRTG_WGHT_PSN_CLASS { get; set; }

        /// <summary>
        /// Desc:抵押权人名称
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string MRTG_WGHT_PSN_NM { get; set; }

        /// <summary>
        /// Desc:抵押权人代码
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string MRTG_WGHT_PSN_CD { get; set; }

        /// <summary>
        /// Desc:抵押权人证件类型
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string MRTG_WGHT_PSN_CRDT_TP { get; set; }

        /// <summary>
        /// Desc:抵押权人证件号码
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string MRTG_WGHT_PSN_CRDT_NO { get; set; }

        /// <summary>
        /// Desc:抵押权人联系电话
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string MRTG_WGHT_PSN_CTC_TEL { get; set; }

        /// <summary>
        /// Desc:抵押权人地址
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string MRTG_WGHT_PSN_ADR { get; set; }

        /// <summary>
        /// Desc:被担保主债权数额
        /// Default:
        /// Nullable:True
        /// </summary>           
        public double PRIM_CLM_WRNT_TOTAL_AMT { get; set; }

        /// <summary>
        /// Desc:存量抵押方式
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string STK_MRTG_MOD { get; set; }

        /// <summary>
        /// Desc:存量权利价值面积
        /// Default:
        /// Nullable:True
        /// </summary>           
        public double STK_RGHT_VAL_AREA { get; set; }

        /// <summary>
        /// Desc:存量抵押权登薄日期
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string STK_MRTG_WGHT_RG_DT { get; set; }

        /// <summary>
        /// Desc:主债权担保金额
        /// Default:
        /// Nullable:True
        /// </summary>           
        public double PRIM_CLM_WRNT_AMT { get; set; }

        /// <summary>
        /// Desc:债权金额
        /// Default:
        /// Nullable:True
        /// </summary>           
        public double CLM_NUM_AMT { get; set; }

        /// <summary>
        /// Desc:债务履行期限（债权确定期间、抵押期限）开始
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string DBT_PRFMN_STDT { get; set; }

        /// <summary>
        /// Desc:债务履行期限（债权确定期间、抵押期限）截止
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string DBT_PRFMN_EDDT { get; set; }

        /// <summary>
        /// Desc:抵押金额
        /// Default:
        /// Nullable:True
        /// </summary>           
        public double MRTG_AMT { get; set; }

        /// <summary>
        /// Desc:债务人信息ID
        /// Default:
        /// Nullable:True
        /// </summary>           
        public string ZWRXX_ID { get; set; }

        [SugarColumn(IsIgnore = true)]
        public List<OBLG> OBLG { get; set; } = new List<OBLG>();

    }
}
